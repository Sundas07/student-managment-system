import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import javax.swing.table.DefaultTableModel;
import java.util.List;

public class StudentManagementSystem extends JFrame {
    private JPanel cardPanel;
    private CardLayout cardLayout;
    private StudentDAO studentDAO;

    public StudentManagementSystem() {
        studentDAO = new StudentDAO();
        setTitle("Student Management System By Sundas");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Create a card layout for navigation
        cardLayout = new CardLayout();
        cardPanel = new JPanel(cardLayout);

        cardPanel.add(createAdminLoginPanel(), "AdminLogin");

        // Add the cover page panel
        cardPanel.add(createCoverPage(), "CoverPage");
        // Add the view students panel
        cardPanel.add(createViewStudentsPanel(), "ViewStudents");
        // Add the add student panel
        cardPanel.add(createAddStudentPanel(), "AddStudent");
        // Add the update student panel
        cardPanel.add(createUpdateStudentPanel(), "UpdateStudent");

        // Add card panel to the frame
        add(cardPanel, BorderLayout.CENTER);
    }

    private JPanel createCoverPage() {
        JPanel coverPanel = new JPanel();
        coverPanel.setLayout(new GridBagLayout());
        coverPanel.setBackground(Color.PINK);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(10, 10, 10, 10); // Add some padding

        JLabel titleLabel = new JLabel("Student Management System By Sundas", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        titleLabel.setForeground(Color.WHITE);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2; // Span two columns for the title
        coverPanel.add(titleLabel, gbc);

        JButton viewButton = create3DButton("View Students");
        viewButton.addActionListener(e -> cardLayout.show(cardPanel, "ViewStudents"));
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 1; // Reset grid width
        coverPanel.add(viewButton, gbc);

        JButton addButton = create3DButton("Add Student");
        addButton.addActionListener(e -> cardLayout.show(cardPanel, "AddStudent"));
        gbc.gridx = 1;
        gbc.gridy = 1;
        coverPanel.add(addButton, gbc);

        JButton deleteButton = create3DButton("Delete Student");
        deleteButton.addActionListener(e -> deleteStudent());
        gbc.gridx = 0;
        gbc.gridy = 2;
        coverPanel.add(deleteButton, gbc);

        JButton updateButton = create3DButton("Update Student");
        updateButton.addActionListener(e -> cardLayout.show(cardPanel, "UpdateStudent"));
        gbc.gridx = 1;
        gbc.gridy = 2;
        coverPanel.add(updateButton, gbc);

        return coverPanel;
    }

    private JButton create3DButton(String text) {
        JButton button = new JButton(text);
        button.setFont(new Font("Arial", Font.BOLD, 16));
        button.setBackground(new Color(240, 240, 240));
        button.setForeground(Color.BLACK);
        button.setBorder(BorderFactory.createRaisedBevelBorder());
        button.setFocusPainted(false);
        button.setPreferredSize(new Dimension(200, 50)); // Increased size of buttons
        return button;
    }

    private JPanel createUpdateStudentPanel() {
        JPanel updatePanel = new JPanel();
        updatePanel.setLayout(new GridLayout(0, 2));
        updatePanel.setBackground(Color.PINK);

        // Create input fields for student details
        updatePanel.add(new JLabel("Student ID:"));
        JTextField idField = new JTextField();
        updatePanel.add(idField);

        updatePanel.add(new JLabel("Name:"));
        JTextField nameField = new JTextField();
        updatePanel.add(nameField);

        updatePanel.add(new JLabel("Age:"));
        JTextField ageField = new JTextField();
        updatePanel.add(ageField);

        updatePanel.add(new JLabel("Gender:"));
        JTextField genderField = new JTextField();
        updatePanel.add(genderField);

        updatePanel.add(new JLabel("Department:"));
        JTextField departmentField = new JTextField();
        updatePanel.add(departmentField);

        updatePanel.add(new JLabel("Contact Number:"));
        JTextField contactField = new JTextField();
        updatePanel.add(contactField);

        updatePanel.add(new JLabel("Email:"));
        JTextField emailField = new JTextField();
        updatePanel.add(emailField);

        updatePanel.add(new JLabel("Address:"));
        JTextField addressField = new JTextField();
        updatePanel.add(addressField);

        updatePanel.add(new JLabel("GPA:"));
        JTextField gpaField = new JTextField();
        updatePanel.add(gpaField);

        updatePanel.add(new JLabel("Enrollment Date:"));
        JTextField enrollmentField = new JTextField();
        updatePanel.add(enrollmentField);

        updatePanel.add(new JLabel("Subjects:"));
        JTextField subjectsField = new JTextField();
        updatePanel.add(subjectsField);

        updatePanel.add(new JLabel("Status:"));
        JTextField statusField = new JTextField();
        updatePanel.add(statusField);

        // Add Update button
        JButton updateButton = new JButton("Update Student");
        updateButton.addActionListener(e -> {
            try {
                int studentId = Integer.parseInt(idField.getText()); // Assuming ID is an integer
                Student student = new Student(nameField.getText(),
                        Integer.parseInt(ageField.getText()),
                        genderField.getText(),
                        departmentField.getText(),
                        contactField.getText(),
                        emailField.getText(),
                        addressField.getText(),
                        Double.parseDouble(gpaField.getText()),
                        enrollmentField.getText(),
                        subjectsField.getText(),
                        statusField.getText());
                studentDAO.updateStudent(studentId, student); // Assuming you have this method in StudentDAO
                JOptionPane.showMessageDialog(updatePanel, "Student updated successfully!");
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(updatePanel, "Error updating student: " + ex.getMessage());
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(updatePanel, "Please enter valid numbers for ID, Age, and GPA.");
            }
        });
        updatePanel.add(updateButton);

        // Add Back button
        JButton backButton = new JButton("Back");
        backButton.addActionListener(e -> cardLayout.show(cardPanel, "CoverPage"));
        updatePanel.add(backButton);

        return updatePanel;
    }

    private JPanel createViewStudentsPanel() {
        JPanel viewPanel = new JPanel();
        viewPanel.setLayout(new BorderLayout());
        viewPanel.setBackground(Color.decode("#87CEEB")); // Sky blue color

        // Column names for the JTable
        String[] columnNames = {
                "Name", "Age", "Gender", "Department", "Contact Number",
                "Email", "Address", "GPA", "Enrollment Date", "Subjects", "Status"
        };

        // Create a model for the JTable
        DefaultTableModel tableModel = new DefaultTableModel(columnNames, 0);
        JTable studentTable = new JTable(tableModel);
        studentTable.setFont(new Font("Monospaced", Font.PLAIN, 12));
        studentTable.setFillsViewportHeight(true);
        studentTable.setBackground(Color.WHITE);

        // Add table to a JScrollPane
        JScrollPane scrollPane = new JScrollPane(studentTable);
        viewPanel.add(scrollPane, BorderLayout.CENTER);

        // Create a panel for buttons
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout());

        // Refresh button
        JButton refreshButton = new JButton("Refresh Students");
        refreshButton.setPreferredSize(new Dimension(150, 40));
        refreshButton.setBackground(Color.MAGENTA); // Colorful background
        refreshButton.setForeground(Color.WHITE); // Text color
        refreshButton.setBorder(BorderFactory.createRaisedBevelBorder()); // 3D effect
        refreshButton.addActionListener(e -> {
            try {
                // Clear existing data in the model
                tableModel.setRowCount(0);

                // Fetch students from DAO
                List<Student> students = studentDAO.getAllStudents();
                for (Student student : students) {
                    // Add each student to the table model
                    tableModel.addRow(new Object[]{
                            student.getName(),
                            student.getAge(),
                            student.getGender(),
                            student.getDepartment(),
                            student.getContactNumber(),
                            student.getEmail(),
                            student.getAddress(),
                            student.getGpa(),
                            student.getEnrollmentDate(),
                            student.getSubjects(),
                            student.getStatus()
                    });
                }
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(viewPanel, "Error fetching students: " + ex.getMessage());
            }
        });
        buttonPanel.add(refreshButton); // Add to button panel

        // Back button
        JButton backButton = new JButton("Back");
        backButton.setPreferredSize(new Dimension(150, 40));
        backButton.setBackground(Color.CYAN); // Colorful background
        backButton.setForeground(Color.BLACK); // Text color
        backButton.setBorder(BorderFactory.createRaisedBevelBorder()); // 3D effect
        backButton.addActionListener(e -> cardLayout.show(cardPanel, "CoverPage"));
        buttonPanel.add(backButton); // Add to button panel

        viewPanel.add(buttonPanel, BorderLayout.SOUTH); // Add button panel to view panel

        return viewPanel;
    }


    private JPanel createAddStudentPanel() {
        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(new GridLayout(12, 2, 10, 10));
        inputPanel.setOpaque(true);
        inputPanel.setBackground(Color.PINK);

        // Adding input fields
        inputPanel.add(createLabel("Name:"));
        JTextField nameField = new JTextField();
        inputPanel.add(nameField);

        inputPanel.add(createLabel("Age:"));
        JTextField ageField = new JTextField();
        inputPanel.add(ageField);

        inputPanel.add(createLabel("Gender:"));
        JTextField genderField = new JTextField();
        inputPanel.add(genderField);

        inputPanel.add(createLabel("Department:"));
        JTextField departmentField = new JTextField();
        inputPanel.add(departmentField);

        inputPanel.add(createLabel("Contact Number:"));
        JTextField contactField = new JTextField();
        inputPanel.add(contactField);

        inputPanel.add(createLabel("Email:"));
        JTextField emailField = new JTextField();
        inputPanel.add(emailField);

        inputPanel.add(createLabel("Address:"));
        JTextField addressField = new JTextField();
        inputPanel.add(addressField);

        inputPanel.add(createLabel("GPA:"));
        JTextField gpaField = new JTextField();
        inputPanel.add(gpaField);

        inputPanel.add(createLabel("Enrollment Date:"));
        JTextField enrollmentField = new JTextField();
        inputPanel.add(enrollmentField);

        inputPanel.add(createLabel("Subjects:"));
        JTextField subjectsField = new JTextField();
        inputPanel.add(subjectsField);

        inputPanel.add(createLabel("Status:"));
        JTextField statusField = new JTextField();
        inputPanel.add(statusField);

        // Add Save button
        JButton saveButton = new JButton("Add Student");
        saveButton.addActionListener(e -> {
            try {
                Student student = new Student(nameField.getText(),
                        Integer.parseInt(ageField.getText()),
                        genderField.getText(),
                        departmentField.getText(),
                        contactField.getText(),
                        emailField.getText(),
                        addressField.getText(),
                        Double.parseDouble(gpaField.getText()),
                        enrollmentField.getText(),
                        subjectsField.getText(),
                        statusField.getText());
                studentDAO.addStudent(student);
                JOptionPane.showMessageDialog(inputPanel, "Student added successfully!");
                clearInputFields(nameField, ageField, genderField, departmentField, contactField, emailField, addressField, gpaField, enrollmentField, subjectsField, statusField);
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(inputPanel, "Error adding student: " + ex.getMessage());
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(inputPanel, "Please enter valid numbers for Age and GPA.");
            }
        });
        inputPanel.add(saveButton);

        // Add Back button
        JButton backButton = new JButton("Back");
        backButton.addActionListener(e -> cardLayout.show(cardPanel, "CoverPage"));
        inputPanel.add(backButton);

        return inputPanel;
    }

    private JLabel createLabel(String text) {
        return new JLabel(text);
    }

    private void clearInputFields(JTextField... fields) {
        for (JTextField field : fields) {
            field.setText("");
        }
    }

    private void deleteStudent() {
        String studentId = JOptionPane.showInputDialog("Enter Student ID to delete:");
        if (studentId != null) {
            try {
                studentDAO.deleteStudent(Integer.parseInt(studentId));
                JOptionPane.showMessageDialog(this, "Student deleted successfully!");
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this, "Error deleting student: " + ex.getMessage());
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Please enter a valid Student ID.");
            }
        }
    }

    private JPanel createAdminLoginPanel() {
        JPanel loginPanel = new JPanel();
        loginPanel.setLayout(new GridBagLayout());
        loginPanel.setBackground(Color.PINK);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(10, 10, 10, 10);

        // Username Label
        JLabel usernameLabel = new JLabel("Username:");
        gbc.gridx = 0;
        gbc.gridy = 0;
        loginPanel.add(usernameLabel, gbc);

        // Username Field
        JTextField usernameField = new JTextField(15);
        gbc.gridx = 1;
        loginPanel.add(usernameField, gbc);

        // Password Label
        JLabel passwordLabel = new JLabel("Password:");
        gbc.gridx = 0;
        gbc.gridy = 1;
        loginPanel.add(passwordLabel, gbc);

        // Password Field
        JPasswordField passwordField = new JPasswordField(15);
        gbc.gridx = 1;
        loginPanel.add(passwordField, gbc);

        // Login Button
        JButton loginButton = new JButton("Login");
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String username = usernameField.getText();
                String password = new String(passwordField.getPassword());

                // Validate credentials (dummy validation)
                if ("admin".equals(username) && "password".equals(password)) {
                    JOptionPane.showMessageDialog(loginPanel, "Login Successful!");
                    cardLayout.show(cardPanel, "CoverPage"); // Redirect to Cover Page
                } else {
                    JOptionPane.showMessageDialog(loginPanel, "Invalid username or password!");
                }
            }
        });
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2; // Span across both columns
        loginPanel.add(loginButton, gbc);

        return loginPanel;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            StudentManagementSystem sms = new StudentManagementSystem();
            sms.setVisible(true);
        });
    }
}
