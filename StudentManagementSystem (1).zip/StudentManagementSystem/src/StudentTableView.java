import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.util.List;

public class StudentTableView {

    // Method to create a graphical view of the student list using JTable
    public void showStudentTable(List<Student> students) {
        // Column headers for the table
        String[] columnNames = {"ID", "Name", "Age", "Gender", "Department", "Contact", "Email", "GPA", "Enrollment Date", "Subjects", "Status", "Address"};

        // Creating table model
        DefaultTableModel model = new DefaultTableModel(columnNames, 0);

        // Populating the table with student data
        for (Student student : students) {
            Object[] rowData = {
                    student.getId(),
                    student.getName(),
                    student.getAge(),
                    student.getGender(),
                    student.getDepartment(),
                    student.getContactNumber(),
                    student.getEmail(),
                    student.getGpa(),
                    student.getEnrollmentDate(),
                    student.getSubjects(),
                    student.getStatus(),
                    student.getAddress()
            };
            model.addRow(rowData);
        }

        // Create JTable with the model
        JTable studentTable = new JTable(model);

        // Set up the GUI (JFrame)
        JFrame frame = new JFrame("Student List");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800, 400);

        // Add the table to the frame within a JScrollPane for scrollable view
        JScrollPane scrollPane = new JScrollPane(studentTable);
        frame.add(scrollPane);

        // Display the frame
        frame.setVisible(true);
    }
}

