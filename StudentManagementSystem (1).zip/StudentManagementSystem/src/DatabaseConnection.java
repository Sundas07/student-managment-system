import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {
    private static final String URL = "jdbc:mysql://localhost:3306/stu_management";
    private static final String USERNAME = "root";  // Your MySQL username
    private static final String PASSWORD = "1234567890noorain==";  // Your MySQL password

    public static Connection getConnection() throws SQLException {
        System.out.println("Connecting to database...");
        return DriverManager.getConnection(URL, USERNAME, PASSWORD);
    }
}
