import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class StudentDAO {
    private static final String URL = "jdbc:mysql://localhost:3306/stu_management";
    private static final String USERNAME = "root";
    private static final String PASSWORD = "1234567890noorain==";

    // Method to add a student to the database
    public void addStudent(Student student) throws SQLException {
        String sql = "INSERT INTO students (name, age, gender, department, contact_number, email, address, gpa, enrollment_date, subjects, status) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setString(1, student.getName());
            statement.setInt(2, student.getAge());
            statement.setString(3, student.getGender());
            statement.setString(4, student.getDepartment());
            statement.setString(5, student.getContactNumber());
            statement.setString(6, student.getEmail());
            statement.setString(7, student.getAddress());
            statement.setDouble(8, student.getGpa());
            statement.setString(9, student.getEnrollmentDate());
            statement.setString(10, student.getSubjects());
            statement.setString(11, student.getStatus());

            statement.executeUpdate();
        }
    }

    // Method to get all students from the database
    public List<Student> getAllStudents() throws SQLException {
        List<Student> students = new ArrayList<>();
        String sql = "SELECT * FROM students";

        try (Connection connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(sql)) {

            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String name = resultSet.getString("name");
                int age = resultSet.getInt("age");
                String gender = resultSet.getString("gender");
                String department = resultSet.getString("department");
                String contactNumber = resultSet.getString("contact_number");
                String email = resultSet.getString("email");
                String address = resultSet.getString("address");
                double gpa = resultSet.getDouble("gpa");
                String enrollmentDate = resultSet.getString("enrollment_date");
                String subjects = resultSet.getString("subjects");
                String status = resultSet.getString("status");

                Student student = new Student(id, name, age, gender, department, contactNumber, email, address, gpa, enrollmentDate, subjects, status);
                students.add(student);
            }
        }

        return students;
    }

    // Method to delete a student
    public void deleteStudent(int studentId) throws SQLException {
        String query = "DELETE FROM students WHERE id = ?";
        try (Connection connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
             PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, studentId);
            statement.executeUpdate();
        }
    }

    // Method to update a student
    public void updateStudent(int studentId, Student student) throws SQLException {
        String sql = "UPDATE students SET name=?, age=?, gender=?, department=?, contact_number=?, email=?, address=?, gpa=?, enrollment_date=?, subjects=?, status=? WHERE id=?";
        try (Connection conn = DriverManager.getConnection(URL, USERNAME, PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, student.getName());
            pstmt.setInt(2, student.getAge());
            pstmt.setString(3, student.getGender());
            pstmt.setString(4, student.getDepartment());
            pstmt.setString(5, student.getContactNumber());
            pstmt.setString(6, student.getEmail());
            pstmt.setString(7, student.getAddress());
            pstmt.setDouble(8, student.getGpa());
            pstmt.setString(9, student.getEnrollmentDate());
            pstmt.setString(10, student.getSubjects());
            pstmt.setString(11, student.getStatus());
            pstmt.setInt(12, studentId); // Assuming ID is an integer

            pstmt.executeUpdate();
        }
    }

    // Method to get a student by ID
    public Student getStudentById(int studentId) throws SQLException {
        String sql = "SELECT * FROM students WHERE id = ?";
        Student student = null;

        try (Connection connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, studentId);
            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                String name = resultSet.getString("name");
                int age = resultSet.getInt("age");
                String gender = resultSet.getString("gender");
                String department = resultSet.getString("department");
                String contactNumber = resultSet.getString("contact_number");
                String email = resultSet.getString("email");
                String address = resultSet.getString("address");
                double gpa = resultSet.getDouble("gpa");
                String enrollmentDate = resultSet.getString("enrollment_date");
                String subjects = resultSet.getString("subjects");
                String status = resultSet.getString("status");

                // Create and return a new Student object
                student = new Student(studentId, name, age, gender, department, contactNumber, email, address, gpa, enrollmentDate, subjects, status);
            }
        }

        return student; // Will return null if student is not found
    }
}
